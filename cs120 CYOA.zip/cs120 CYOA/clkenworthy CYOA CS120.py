""" CS120 CLKenworthy
    CYOA game"""

def makeGame():
    game = {
      "start": ["You come across a dark looking cave.", "Go home, this is too much.", "lame", "Start your adventure.", "cave"], 
      "cave": ["You enter the cave. You immediately see a skeleton with some pretty valueable loot. Take it?", "Take the riches", "riches", "Carry on, money isn't what you're looking for.", "rags"], 
      "lame": ["Are you even an adventurer? This is just a cave!!", "Start over", "start", "Quit", "quit"], 
      "riches": ["Once you pick up the gold, you hear a *click*. You barely notice the booby trap as it explodes.", "Start over", "start", "Quit", "quit"], 
      "rags": ["You move past the skeleton and immediately run into a Slime!", "Lure it to the skeleton", "lure", "Charge! Full speed ahead!", "bullrush"], 
      "lure": ["The slime follows you to the skeleton and its riches start to disentigrate. Making sure you're a safe distance away, the slime explodes!", "Catch your breath", "relax", "See whats left", "invest"], 
      "bullrush": ["This slime didn't see you coming!! Because you tripped and fell on top of it. What a sad way to go.", "Start over", "start", "Quit", "quit"], 
      "relax": ["You take a few moments to calm yourself, but something else doens't have nerves to calm. The slime is still alive! It latches what little is left of it on your armor, and you can't get it off! Game over.", "Start over", "start", "Quit", "quit"], 
      "invest": ["With no time to waste, you check back on the skeleton. To your surprise, the slime is still alive, just in small scattered bits and pieces.", "Finish it off", "slay", "I kinda feel bad for it?", "strange"], 
      "slay": ["Using your blade, you slice at the slime until it begins to evaporate. Maybe thats enough of this cave.", "Leave it behind", "leave", "Continue exploring", "stay"], 
      "strange": ["It doesn't really do anything but wobble. I think I should leave.", "Leave the cave", "leave", "Eh, it couldn't hurt to keep looking", "stay"], 
      "leave": ["Seems that explosion was really strong, because the moment you walk out, the cave collapses on itself. You survived!", "Start over", "start", "Quit", "quit"], 
      "stay": ["You start literally crawling through this cave when really heavy rumbling starts. You are crushed under the following rubble.", "Start over", "start", "Quit", "quit"], 
 }
    return game

def playNode(game, node):
    activeNode = game[node]
    (description, menu1, node1, menu2, node2) = activeNode
    print(f"""
   {description}
   1. {menu1}
   2. {menu2}
    """)
    userChoice = input("Choose your path (1/2): ")
    if userChoice == "1":
        newNode = node1
    elif userChoice == "2":
        newNode = node2
    else:
        print("Please choose option 1 or 2.")
        newNode = activeNode
    return newNode

def main():
    game = makeGame()
    activeNode = "start"
    keepGoing = True
    while keepGoing:
        if activeNode == "quit":
            print("""
     GAME OVER
     """)
            keepGoing = False
        else:
            activeNode = playNode(game, activeNode)

main()
